sap.ui.define(["sap/fe/core/AppComponent"],function(o){"use strict";return o.extend("com.sap.bookshop.bookshop.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map